import { useState } from 'react';
import { Package, ClipboardList, AlertTriangle, Truck } from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { KPICard } from './components/KPICard';
import { OrdersBarChart } from './components/OrdersBarChart';
import { OrdersPieChart } from './components/OrdersPieChart';
import { ActivityTable } from './components/ActivityTable';
import { WarehouseCapacity } from './components/WarehouseCapacity';
import { CriticalProductsAlert } from './components/CriticalProductsAlert';
import { MiniCalendar } from './components/MiniCalendar';
import { AnagrafichePage } from './components/AnagrafichePage';
import { WarehousePage } from './components/WarehousePage';
import { PurchasesPage } from './components/PurchasesPage';
import { SalesPage } from './components/SalesPage';
import { LogisticsPage } from './components/LogisticsPage';
import { AdministrationPage } from './components/AdministrationPage';

type Page = 'dashboard' | 'anagrafiche' | 'magazzino' | 'acquisti' | 'vendite' | 'logistica' | 'amministrazione';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  const handleNavigate = (page: string) => {
    if (page === 'dashboard' || page === 'anagrafiche' || page === 'magazzino' || page === 'acquisti' || page === 'vendite' || page === 'logistica' || page === 'amministrazione') {
      setCurrentPage(page as Page);
    } else if (page === 'clienti' || page === 'fornitori' || page === 'prodotti') {
      setCurrentPage('anagrafiche');
    } else {
      setCurrentPage('dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      <Sidebar onNavigate={handleNavigate} activePage={currentPage} />
      <Header />

      <main className="ml-[260px] mt-16 p-6">
        {currentPage === 'dashboard' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <KPICard
                icon={Package}
                title="Valore Totale Stock"
                value="€ 2.540.000"
                trend={12.4}
                iconBgColor="bg-gradient-to-br from-[#3B82F6] to-[#2563EB]"
                iconColor="text-white"
              />
              <KPICard
                icon={ClipboardList}
                title="Ordini da Evadere"
                value="128"
                trend={8.2}
                iconBgColor="bg-gradient-to-br from-[#F59E0B] to-[#D97706]"
                iconColor="text-white"
              />
              <KPICard
                icon={AlertTriangle}
                title="Prodotti Sottoscorta"
                value="23"
                trend={-5.1}
                iconBgColor="bg-gradient-to-br from-[#EF4444] to-[#DC2626]"
                iconColor="text-white"
              />
              <KPICard
                icon={Truck}
                title="Spedizioni Odierne"
                value="87"
                trend={15.7}
                iconBgColor="bg-gradient-to-br from-[#17E88F] to-[#0FA67A]"
                iconColor="text-white"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <div className="lg:col-span-2">
                <OrdersBarChart />
              </div>
              <div>
                <OrdersPieChart />
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              <WarehouseCapacity />
              <CriticalProductsAlert />
              <MiniCalendar />
            </div>

            <ActivityTable />
          </>
        )}

        {currentPage === 'anagrafiche' && <AnagrafichePage />}

        {currentPage === 'magazzino' && <WarehousePage />}

        {currentPage === 'acquisti' && <PurchasesPage />}

        {currentPage === 'vendite' && <SalesPage />}

        {currentPage === 'logistica' && <LogisticsPage />}

        {currentPage === 'amministrazione' && <AdministrationPage />}
      </main>
    </div>
  );
}