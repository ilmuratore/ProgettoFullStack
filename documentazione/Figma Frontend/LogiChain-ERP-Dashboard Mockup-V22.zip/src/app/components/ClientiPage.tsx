import { useState } from 'react';
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Mail,
  Phone,
  MapPin
} from 'lucide-react';

interface Cliente {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  fatturato: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

const clienti: Cliente[] = [
  { id: 1, ragioneSociale: 'Logistica Express S.r.l.', codice: 'CLI-001', pIva: 'IT02345678901', citta: 'Milano', email: 'info@logisticaexpress.it', telefono: '+39 02 1234567', fatturato: '€ 850.000', stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Transport Solutions S.p.A.', codice: 'CLI-002', pIva: 'IT03456789012', citta: 'Roma', email: 'contact@transportsolutions.it', telefono: '+39 06 7654321', fatturato: '€ 1.200.000', stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Distribuzione Veloce S.r.l.', codice: 'CLI-003', pIva: 'IT04567890123', citta: 'Torino', email: 'info@distribuzioneveloce.it', telefono: '+39 011 9876543', fatturato: '€ 520.000', stato: 'Attivo' },
  { id: 4, ragioneSociale: 'Cargo Italia S.p.A.', codice: 'CLI-004', pIva: 'IT05678901234', citta: 'Bologna', email: 'sales@cargoitalia.it', telefono: '+39 051 3456789', fatturato: '€ 975.000', stato: 'Sospeso' },
  { id: 5, ragioneSociale: 'Freight Forward S.r.l.', codice: 'CLI-005', pIva: 'IT06789012345', citta: 'Napoli', email: 'info@freightforward.it', telefono: '+39 081 2468135', fatturato: '€ 680.000', stato: 'Attivo' },
  { id: 6, ragioneSociale: 'Supply Chain Pro S.r.l.', codice: 'CLI-006', pIva: 'IT07890123456', citta: 'Firenze', email: 'contact@supplychainpro.it', telefono: '+39 055 1357924', fatturato: '€ 1.450.000', stato: 'Attivo' },
  { id: 7, ragioneSociale: 'Trasporti Nazionali S.p.A.', codice: 'CLI-007', pIva: 'IT08901234567', citta: 'Genova', email: 'info@trasportinazionali.it', telefono: '+39 010 8642097', fatturato: '€ 320.000', stato: 'Inattivo' },
  { id: 8, ragioneSociale: 'Spedizioni Rapide S.r.l.', codice: 'CLI-008', pIva: 'IT09012345678', citta: 'Verona', email: 'sales@spedizionirapide.it', telefono: '+39 045 7531598', fatturato: '€ 890.000', stato: 'Attivo' },
];

export function ClientiPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const getStatoBadgeColor = (stato: string) => {
    switch (stato) {
      case 'Attivo':
        return 'bg-[#DCFCE7] text-[#22C55E]';
      case 'Sospeso':
        return 'bg-[#FEF3C7] text-[#F59E0B]';
      case 'Inattivo':
        return 'bg-[#FEE2E2] text-[#EF4444]';
      default:
        return 'bg-[#F3F4F6] text-[#6B7280]';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-[#2D2D2D]">Clienti</h1>
        <p className="text-sm text-[#6B7280] mt-1">Gestione anagrafica clienti</p>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Importa
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta
          </button>
        </div>
        <button className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium">
          <Plus className="w-4 h-4" />
          Nuovo Cliente
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cerca clienti..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
            />
          </div>
          <button className="px-4 py-2 bg-[#F7F9FC] border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-white transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5EAF2]">
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fatturato</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {clienti.map((cliente, index) => (
                <tr
                  key={cliente.id}
                  className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                    index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                  }`}
                >
                  <td className="py-3 px-4">
                    <div className="font-medium text-[#2D2D2D]">{cliente.ragioneSociale}</div>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{cliente.codice}</td>
                  <td className="py-3 px-4 text-sm text-[#6B7280]">{cliente.pIva}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                      <MapPin className="w-3 h-3" />
                      {cliente.citta}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                        <Mail className="w-3 h-3" />
                        {cliente.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                        <Phone className="w-3 h-3" />
                        {cliente.telefono}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{cliente.fatturato}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(cliente.stato)}`}>
                      {cliente.stato}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#E5EAF2]">
          <div className="text-sm text-[#6B7280]">
            Mostrando <span className="font-medium text-[#2D2D2D]">{clienti.length}</span> di <span className="font-medium text-[#2D2D2D]">{clienti.length}</span> risultati
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Precedente
            </button>
            <button className="px-3 py-1.5 bg-[#17E88F] text-white rounded-lg font-medium text-sm">
              1
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              2
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Successivo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
