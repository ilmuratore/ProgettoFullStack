import { useState } from 'react';
import { Plus } from 'lucide-react';
import { WarehouseKPIs } from './warehouse/WarehouseKPIs';
import { WarehouseTreeView } from './warehouse/WarehouseTreeView';
import { WarehouseWidgets } from './warehouse/WarehouseWidgets';
import { StockTable } from './warehouse/StockTable';
import { StockMovementsTimeline } from './warehouse/StockMovementsTimeline';
import { NewMovementModal } from './warehouse/NewMovementModal';

export function WarehousePage() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Magazzino</h1>
          <p className="text-sm text-[#6B7280] mt-1">Dashboard / Magazzino</p>
        </div>
      </div>

      <WarehouseKPIs />

      <div className="grid grid-cols-1 lg:grid-cols-10 gap-6">
        <div className="lg:col-span-7">
          <WarehouseTreeView />
        </div>
        <div className="lg:col-span-3">
          <WarehouseWidgets />
        </div>
      </div>

      <StockTable />

      <StockMovementsTimeline />

      <button
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-full shadow-2xl hover:shadow-3xl hover:scale-110 transition-all duration-300 flex items-center justify-center group"
      >
        <Plus className="w-8 h-8 group-hover:rotate-90 transition-transform duration-300" />
      </button>

      <div className="fixed bottom-28 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="bg-[#2D2D2D] text-white px-3 py-2 rounded-lg text-sm font-medium shadow-lg">
          Nuovo Movimento
        </div>
      </div>

      <NewMovementModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
