import { useState } from 'react';
import { Plus, DollarSign, Download, Filter } from 'lucide-react';
import { AdminKPIs } from './administration/AdminKPIs';
import { InvoicesTable } from './administration/InvoicesTable';
import { FinancialWidgets } from './administration/FinancialWidgets';
import { CashFlowChart } from './administration/CashFlowChart';
import { PaymentSchedule } from './administration/PaymentSchedule';
import { RecentPayments } from './administration/RecentPayments';
import { EconomicAnalysis } from './administration/EconomicAnalysis';
import { CriticalPartners } from './administration/CriticalPartners';
import { InvoiceDrawer } from './administration/InvoiceDrawer';
import { NewInvoiceModal } from './administration/NewInvoiceModal';
import { RecentActivities } from './administration/RecentActivities';

export function AdministrationPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Amministrazione</h1>
          <p className="text-sm text-[#6B7280] mt-1">Dashboard / Amministrazione</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri Avanzati
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta Report
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            Registra Pagamento
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium"
          >
            <Plus className="w-4 h-4" />
            Nuova Fattura
          </button>
        </div>
      </div>

      {/* KPIs */}
      <AdminKPIs />

      {/* Main 70/30 Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-10 gap-6">
        <div className="lg:col-span-7">
          <InvoicesTable onInvoiceClick={setSelectedInvoiceId} />
        </div>
        <div className="lg:col-span-3">
          <FinancialWidgets />
        </div>
      </div>

      {/* Cash Flow */}
      <CashFlowChart />

      {/* Scadenziario */}
      <PaymentSchedule />

      {/* Incassi e Pagamenti */}
      <RecentPayments />

      {/* Analisi Economica */}
      <EconomicAnalysis />

      {/* Clienti e Fornitori Critici */}
      <CriticalPartners />

      {/* Attività Recenti */}
      <RecentActivities />

      {/* Drawer */}
      <InvoiceDrawer
        invoiceId={selectedInvoiceId}
        isOpen={!!selectedInvoiceId}
        onClose={() => setSelectedInvoiceId(null)}
      />

      {/* Modal */}
      <NewInvoiceModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}
