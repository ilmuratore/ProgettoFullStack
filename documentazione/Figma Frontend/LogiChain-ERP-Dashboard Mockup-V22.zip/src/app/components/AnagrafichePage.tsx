import { useState } from 'react';
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Mail,
  Phone,
  MapPin,
  Building2,
  Package,
  User
} from 'lucide-react';

type TabType = 'clienti' | 'fornitori' | 'prodotti';

interface Cliente {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  fatturato: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

interface Fornitore {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  categoria: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

interface Prodotto {
  id: number;
  nome: string;
  sku: string;
  categoria: string;
  fornitore: string;
  prezzo: string;
  giacenza: number;
  minimoScorta: number;
  stato: 'Disponibile' | 'Esaurito' | 'In Arrivo';
}

const clienti: Cliente[] = [
  { id: 1, ragioneSociale: 'Logistica Express S.r.l.', codice: 'CLI-001', pIva: 'IT02345678901', citta: 'Milano', email: 'info@logisticaexpress.it', telefono: '+39 02 1234567', fatturato: '€ 850.000', stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Transport Solutions S.p.A.', codice: 'CLI-002', pIva: 'IT03456789012', citta: 'Roma', email: 'contact@transportsolutions.it', telefono: '+39 06 7654321', fatturato: '€ 1.200.000', stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Distribuzione Veloce S.r.l.', codice: 'CLI-003', pIva: 'IT04567890123', citta: 'Torino', email: 'info@distribuzioneveloce.it', telefono: '+39 011 9876543', fatturato: '€ 520.000', stato: 'Attivo' },
  { id: 4, ragioneSociale: 'Cargo Italia S.p.A.', codice: 'CLI-004', pIva: 'IT05678901234', citta: 'Bologna', email: 'sales@cargoitalia.it', telefono: '+39 051 3456789', fatturato: '€ 975.000', stato: 'Sospeso' },
  { id: 5, ragioneSociale: 'Freight Forward S.r.l.', codice: 'CLI-005', pIva: 'IT06789012345', citta: 'Napoli', email: 'info@freightforward.it', telefono: '+39 081 2468135', fatturato: '€ 680.000', stato: 'Attivo' },
  { id: 6, ragioneSociale: 'Supply Chain Pro S.r.l.', codice: 'CLI-006', pIva: 'IT07890123456', citta: 'Firenze', email: 'contact@supplychainpro.it', telefono: '+39 055 1357924', fatturato: '€ 1.450.000', stato: 'Attivo' },
  { id: 7, ragioneSociale: 'Trasporti Nazionali S.p.A.', codice: 'CLI-007', pIva: 'IT08901234567', citta: 'Genova', email: 'info@trasportinazionali.it', telefono: '+39 010 8642097', fatturato: '€ 320.000', stato: 'Inattivo' },
  { id: 8, ragioneSociale: 'Spedizioni Rapide S.r.l.', codice: 'CLI-008', pIva: 'IT09012345678', citta: 'Verona', email: 'sales@spedizionirapide.it', telefono: '+39 045 7531598', fatturato: '€ 890.000', stato: 'Attivo' },
];

const fornitori: Fornitore[] = [
  { id: 1, ragioneSociale: 'Packaging Solutions Italia S.p.A.', codice: 'FOR-001', pIva: 'IT12345678901', citta: 'Milano', email: 'vendite@packagingsolutions.it', telefono: '+39 02 9876543', categoria: 'Imballaggi', stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Materiali Logistica Pro S.r.l.', codice: 'FOR-002', pIva: 'IT23456789012', citta: 'Bergamo', email: 'ordini@materialilogistica.it', telefono: '+39 035 1234567', categoria: 'Materiali', stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Pallet Systems Europe S.p.A.', codice: 'FOR-003', pIva: 'IT34567890123', citta: 'Brescia', email: 'info@palletsystems.it', telefono: '+39 030 7654321', categoria: 'Pallet', stato: 'Attivo' },
  { id: 4, ragioneSociale: 'Etichette Professionali S.r.l.', codice: 'FOR-004', pIva: 'IT45678901234', citta: 'Padova', email: 'commerciale@etichettepro.it', telefono: '+39 049 3698521', categoria: 'Etichette', stato: 'Attivo' },
  { id: 5, ragioneSociale: 'Film Protezione Italia S.p.A.', codice: 'FOR-005', pIva: 'IT56789012345', citta: 'Vicenza', email: 'vendite@filmprotezione.it', telefono: '+39 0444 258963', categoria: 'Film', stato: 'Sospeso' },
  { id: 6, ragioneSociale: 'Nastri & Reggette S.r.l.', codice: 'FOR-006', pIva: 'IT67890123456', citta: 'Treviso', email: 'info@nastrireggette.it', telefono: '+39 0422 147258', categoria: 'Nastri', stato: 'Attivo' },
  { id: 7, ragioneSociale: 'Scatole Cartone Europa S.p.A.', codice: 'FOR-007', pIva: 'IT78901234567', citta: 'Bologna', email: 'ordini@scatoleeuropa.it', telefono: '+39 051 9638527', categoria: 'Scatole', stato: 'Attivo' },
  { id: 8, ragioneSociale: 'Protezione Merci S.r.l.', codice: 'FOR-008', pIva: 'IT89012345678', citta: 'Modena', email: 'commerciale@protezionemerci.it', telefono: '+39 059 7418529', categoria: 'Protezione', stato: 'Attivo' },
];

const prodotti: Prodotto[] = [
  { id: 1, nome: 'Pallet Standard EUR 1200x800', sku: 'PLT-EUR-001', categoria: 'Pallet', fornitore: 'Pallet Systems Europe', prezzo: '€ 12,50', giacenza: 450, minimoScorta: 200, stato: 'Disponibile' },
  { id: 2, nome: 'Scatola Cartone Ondulato 40x30x30', sku: 'SCT-OND-045', categoria: 'Scatole', fornitore: 'Scatole Cartone Europa', prezzo: '€ 0,85', giacenza: 2500, minimoScorta: 1000, stato: 'Disponibile' },
  { id: 3, nome: 'Film Estensibile Trasparente 50cm', sku: 'FLM-EST-012', categoria: 'Film', fornitore: 'Film Protezione Italia', prezzo: '€ 18,90', giacenza: 12, minimoScorta: 50, stato: 'Esaurito' },
  { id: 4, nome: 'Etichette Adesive A4 Bianche', sku: 'ETI-ADE-098', categoria: 'Etichette', fornitore: 'Etichette Professionali', prezzo: '€ 24,50', giacenza: 180, minimoScorta: 100, stato: 'Disponibile' },
  { id: 5, nome: 'Reggetta PP Automatica 12mm', sku: 'REG-PP-034', categoria: 'Reggette', fornitore: 'Nastri & Reggette', prezzo: '€ 32,00', giacenza: 95, minimoScorta: 80, stato: 'Disponibile' },
  { id: 6, nome: 'Nastro Adesivo Avana 50mm', sku: 'NST-AVA-056', categoria: 'Nastri', fornitore: 'Nastri & Reggette', prezzo: '€ 1,20', giacenza: 8, minimoScorta: 30, stato: 'Esaurito' },
  { id: 7, nome: 'Angolare Cartone Protezione 50x50', sku: 'ANG-CRT-067', categoria: 'Protezione', fornitore: 'Protezione Merci', prezzo: '€ 0,45', giacenza: 850, minimoScorta: 500, stato: 'Disponibile' },
  { id: 8, nome: 'Busta Pluriball 30x45cm', sku: 'BST-PLU-089', categoria: 'Protezione', fornitore: 'Protezione Merci', prezzo: '€ 0,38', giacenza: 1200, minimoScorta: 800, stato: 'Disponibile' },
  { id: 9, nome: 'Etichette Termiche 100x150mm', sku: 'ETI-TRM-112', categoria: 'Etichette', fornitore: 'Etichette Professionali', prezzo: '€ 45,00', giacenza: 0, minimoScorta: 100, stato: 'In Arrivo' },
  { id: 10, nome: 'Pallet in Plastica 1200x1000', sku: 'PLT-PLA-003', categoria: 'Pallet', fornitore: 'Pallet Systems Europe', prezzo: '€ 28,00', giacenza: 220, minimoScorta: 150, stato: 'Disponibile' },
];

export function AnagrafichePage() {
  const [activeTab, setActiveTab] = useState<TabType>('clienti');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'clienti' as TabType, label: 'Clienti', icon: User, count: clienti.length },
    { id: 'fornitori' as TabType, label: 'Fornitori', icon: Building2, count: fornitori.length },
    { id: 'prodotti' as TabType, label: 'Prodotti', icon: Package, count: prodotti.length },
  ];

  const getStatoBadgeColor = (stato: string) => {
    switch (stato) {
      case 'Attivo':
      case 'Disponibile':
        return 'bg-[#DCFCE7] text-[#22C55E]';
      case 'Sospeso':
      case 'In Arrivo':
        return 'bg-[#FEF3C7] text-[#F59E0B]';
      case 'Inattivo':
      case 'Esaurito':
        return 'bg-[#FEE2E2] text-[#EF4444]';
      default:
        return 'bg-[#F3F4F6] text-[#6B7280]';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Gestione Anagrafiche</h1>
          <p className="text-sm text-[#6B7280] mt-1">Gestisci clienti, fornitori e prodotti</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Importa
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium">
            <Plus className="w-4 h-4" />
            Nuovo {activeTab === 'clienti' ? 'Cliente' : activeTab === 'fornitori' ? 'Fornitore' : 'Prodotto'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-1">
        <div className="flex items-center gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#F0FDF7] text-[#17E88F] shadow-sm'
                    : 'text-[#6B7280] hover:bg-[#F7F9FC]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
                <span className={`px-2 py-0.5 rounded-lg text-xs font-medium ${
                  activeTab === tab.id ? 'bg-[#17E88F] text-white' : 'bg-[#E5EAF2] text-[#6B7280]'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={`Cerca ${activeTab}...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
            />
          </div>
          <button className="px-4 py-2 bg-[#F7F9FC] border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-white transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri
          </button>
        </div>

        <div className="overflow-x-auto">
          {activeTab === 'clienti' && (
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5EAF2]">
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fatturato</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                </tr>
              </thead>
              <tbody>
                {clienti.map((cliente, index) => (
                  <tr
                    key={cliente.id}
                    className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                      index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#2D2D2D]">{cliente.ragioneSociale}</div>
                    </td>
                    <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{cliente.codice}</td>
                    <td className="py-3 px-4 text-sm text-[#6B7280]">{cliente.pIva}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                        <MapPin className="w-3 h-3" />
                        {cliente.citta}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                          <Mail className="w-3 h-3" />
                          {cliente.email}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                          <Phone className="w-3 h-3" />
                          {cliente.telefono}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{cliente.fatturato}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(cliente.stato)}`}>
                        {cliente.stato}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'fornitori' && (
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5EAF2]">
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                </tr>
              </thead>
              <tbody>
                {fornitori.map((fornitore, index) => (
                  <tr
                    key={fornitore.id}
                    className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                      index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#2D2D2D]">{fornitore.ragioneSociale}</div>
                    </td>
                    <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{fornitore.codice}</td>
                    <td className="py-3 px-4 text-sm text-[#6B7280]">{fornitore.pIva}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                        <MapPin className="w-3 h-3" />
                        {fornitore.citta}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                          <Mail className="w-3 h-3" />
                          {fornitore.email}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                          <Phone className="w-3 h-3" />
                          {fornitore.telefono}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                        {fornitore.categoria}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(fornitore.stato)}`}>
                        {fornitore.stato}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'prodotti' && (
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5EAF2]">
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Nome Prodotto</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">SKU</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fornitore</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Prezzo</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Giacenza</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                </tr>
              </thead>
              <tbody>
                {prodotti.map((prodotto, index) => (
                  <tr
                    key={prodotto.id}
                    className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                      index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-medium text-[#2D2D2D]">{prodotto.nome}</div>
                    </td>
                    <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{prodotto.sku}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                        {prodotto.categoria}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-[#6B7280]">{prodotto.fornitore}</td>
                    <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{prodotto.prezzo}</td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="text-sm font-medium text-[#2D2D2D]">{prodotto.giacenza} pz</div>
                        <div className="text-xs text-[#6B7280]">Min: {prodotto.minimoScorta}</div>
                        <div className="w-full h-1.5 bg-[#F3F4F6] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              prodotto.giacenza > prodotto.minimoScorta
                                ? 'bg-[#22C55E]'
                                : prodotto.giacenza > 0
                                ? 'bg-[#F59E0B]'
                                : 'bg-[#EF4444]'
                            }`}
                            style={{ width: `${Math.min((prodotto.giacenza / prodotto.minimoScorta) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(prodotto.stato)}`}>
                        {prodotto.stato}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#E5EAF2]">
          <div className="text-sm text-[#6B7280]">
            Mostrando <span className="font-medium text-[#2D2D2D]">
              {activeTab === 'clienti' ? clienti.length : activeTab === 'fornitori' ? fornitori.length : prodotti.length}
            </span> di <span className="font-medium text-[#2D2D2D]">
              {activeTab === 'clienti' ? clienti.length : activeTab === 'fornitori' ? fornitori.length : prodotti.length}
            </span> risultati
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Precedente
            </button>
            <button className="px-3 py-1.5 bg-[#17E88F] text-white rounded-lg font-medium text-sm">
              1
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              2
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              3
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Successivo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
