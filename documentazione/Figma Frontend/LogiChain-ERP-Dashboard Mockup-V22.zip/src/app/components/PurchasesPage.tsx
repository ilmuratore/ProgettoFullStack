import { useState } from 'react';
import { Plus, Download, Filter } from 'lucide-react';
import { PurchaseKPIs } from './purchases/PurchaseKPIs';
import { PurchaseOrdersTable } from './purchases/PurchaseOrdersTable';
import { PurchaseWidgets } from './purchases/PurchaseWidgets';
import { GoodsReceiptsTimeline } from './purchases/GoodsReceiptsTimeline';
import { SuppliersPerformance } from './purchases/SuppliersPerformance';
import { OrderDetailDrawer } from './purchases/OrderDetailDrawer';
import { NewPurchaseOrderModal } from './purchases/NewPurchaseOrderModal';

export function PurchasesPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Acquisti</h1>
          <p className="text-sm text-[#6B7280] mt-1">Dashboard / Acquisti</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri Avanzati
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta Excel
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium"
          >
            <Plus className="w-4 h-4" />
            Nuovo Ordine Acquisto
          </button>
        </div>
      </div>

      <PurchaseKPIs />

      <div className="grid grid-cols-1 lg:grid-cols-10 gap-6">
        <div className="lg:col-span-7">
          <PurchaseOrdersTable onOrderClick={setSelectedOrderId} />
        </div>
        <div className="lg:col-span-3">
          <PurchaseWidgets />
        </div>
      </div>

      <GoodsReceiptsTimeline />

      <SuppliersPerformance />

      <OrderDetailDrawer
        orderId={selectedOrderId}
        isOpen={!!selectedOrderId}
        onClose={() => setSelectedOrderId(null)}
      />

      <NewPurchaseOrderModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}
