import { useState } from 'react';
import { Plus, Download, Filter } from 'lucide-react';
import { SalesKPIs } from './sales/SalesKPIs';
import { SalesOrdersTable } from './sales/SalesOrdersTable';
import { SalesWidgets } from './sales/SalesWidgets';
import { SalesChart } from './sales/SalesChart';
import { TopClienti } from './sales/TopClienti';
import { SalesShipments } from './sales/SalesShipments';
import { SalesOrderDrawer } from './sales/SalesOrderDrawer';
import { NewSalesOrderModal } from './sales/NewSalesOrderModal';
import { SalesRecentActivity } from './sales/SalesRecentActivity';

export function SalesPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Vendite</h1>
          <p className="text-sm text-[#6B7280] mt-1">Dashboard / Vendite</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri Avanzati
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta Ordini
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium"
          >
            <Plus className="w-4 h-4" />
            Nuovo Ordine Cliente
          </button>
        </div>
      </div>

      {/* KPIs */}
      <SalesKPIs />

      {/* Main 70/30 layout */}
      <div className="grid grid-cols-1 lg:grid-cols-10 gap-6">
        <div className="lg:col-span-7">
          <SalesOrdersTable onOrderClick={setSelectedOrderId} />
        </div>
        <div className="lg:col-span-3">
          <SalesWidgets />
        </div>
      </div>

      {/* Andamento Vendite */}
      <SalesChart />

      {/* Top Clienti */}
      <TopClienti />

      {/* Spedizioni */}
      <SalesShipments />

      {/* Attività Recenti */}
      <SalesRecentActivity />

      {/* Drawer */}
      <SalesOrderDrawer
        orderId={selectedOrderId}
        isOpen={!!selectedOrderId}
        onClose={() => setSelectedOrderId(null)}
      />

      {/* Modal */}
      <NewSalesOrderModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}
