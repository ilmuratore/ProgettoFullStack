import { useState } from 'react';
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';

interface Prodotto {
  id: number;
  nome: string;
  sku: string;
  categoria: string;
  fornitore: string;
  prezzo: string;
  giacenza: number;
  minimoScorta: number;
  stato: 'Disponibile' | 'Esaurito' | 'In Arrivo';
}

const prodotti: Prodotto[] = [
  { id: 1, nome: 'Pallet Standard EUR 1200x800', sku: 'PLT-EUR-001', categoria: 'Pallet', fornitore: 'Pallet Systems Europe', prezzo: '€ 12,50', giacenza: 450, minimoScorta: 200, stato: 'Disponibile' },
  { id: 2, nome: 'Scatola Cartone Ondulato 40x30x30', sku: 'SCT-OND-045', categoria: 'Scatole', fornitore: 'Scatole Cartone Europa', prezzo: '€ 0,85', giacenza: 2500, minimoScorta: 1000, stato: 'Disponibile' },
  { id: 3, nome: 'Film Estensibile Trasparente 50cm', sku: 'FLM-EST-012', categoria: 'Film', fornitore: 'Film Protezione Italia', prezzo: '€ 18,90', giacenza: 12, minimoScorta: 50, stato: 'Esaurito' },
  { id: 4, nome: 'Etichette Adesive A4 Bianche', sku: 'ETI-ADE-098', categoria: 'Etichette', fornitore: 'Etichette Professionali', prezzo: '€ 24,50', giacenza: 180, minimoScorta: 100, stato: 'Disponibile' },
  { id: 5, nome: 'Reggetta PP Automatica 12mm', sku: 'REG-PP-034', categoria: 'Reggette', fornitore: 'Nastri & Reggette', prezzo: '€ 32,00', giacenza: 95, minimoScorta: 80, stato: 'Disponibile' },
  { id: 6, nome: 'Nastro Adesivo Avana 50mm', sku: 'NST-AVA-056', categoria: 'Nastri', fornitore: 'Nastri & Reggette', prezzo: '€ 1,20', giacenza: 8, minimoScorta: 30, stato: 'Esaurito' },
  { id: 7, nome: 'Angolare Cartone Protezione 50x50', sku: 'ANG-CRT-067', categoria: 'Protezione', fornitore: 'Protezione Merci', prezzo: '€ 0,45', giacenza: 850, minimoScorta: 500, stato: 'Disponibile' },
  { id: 8, nome: 'Busta Pluriball 30x45cm', sku: 'BST-PLU-089', categoria: 'Protezione', fornitore: 'Protezione Merci', prezzo: '€ 0,38', giacenza: 1200, minimoScorta: 800, stato: 'Disponibile' },
  { id: 9, nome: 'Etichette Termiche 100x150mm', sku: 'ETI-TRM-112', categoria: 'Etichette', fornitore: 'Etichette Professionali', prezzo: '€ 45,00', giacenza: 0, minimoScorta: 100, stato: 'In Arrivo' },
  { id: 10, nome: 'Pallet in Plastica 1200x1000', sku: 'PLT-PLA-003', categoria: 'Pallet', fornitore: 'Pallet Systems Europe', prezzo: '€ 28,00', giacenza: 220, minimoScorta: 150, stato: 'Disponibile' },
];

export function ProdottiPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const getStatoBadgeColor = (stato: string) => {
    switch (stato) {
      case 'Disponibile':
        return 'bg-[#DCFCE7] text-[#22C55E]';
      case 'In Arrivo':
        return 'bg-[#FEF3C7] text-[#F59E0B]';
      case 'Esaurito':
        return 'bg-[#FEE2E2] text-[#EF4444]';
      default:
        return 'bg-[#F3F4F6] text-[#6B7280]';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-[#2D2D2D]">Prodotti</h1>
        <p className="text-sm text-[#6B7280] mt-1">Catalogo e gestione articoli</p>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Importa
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta
          </button>
        </div>
        <button className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium">
          <Plus className="w-4 h-4" />
          Nuovo Prodotto
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cerca prodotti..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
            />
          </div>
          <button className="px-4 py-2 bg-[#F7F9FC] border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-white transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5EAF2]">
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Nome Prodotto</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">SKU</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fornitore</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Prezzo</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Giacenza</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {prodotti.map((prodotto, index) => (
                <tr
                  key={prodotto.id}
                  className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                    index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                  }`}
                >
                  <td className="py-3 px-4">
                    <div className="font-medium text-[#2D2D2D]">{prodotto.nome}</div>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{prodotto.sku}</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                      {prodotto.categoria}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#6B7280]">{prodotto.fornitore}</td>
                  <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{prodotto.prezzo}</td>
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <div className="text-sm font-medium text-[#2D2D2D]">{prodotto.giacenza} pz</div>
                      <div className="text-xs text-[#6B7280]">Min: {prodotto.minimoScorta}</div>
                      <div className="w-full h-1.5 bg-[#F3F4F6] rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            prodotto.giacenza > prodotto.minimoScorta
                              ? 'bg-[#22C55E]'
                              : prodotto.giacenza > 0
                              ? 'bg-[#F59E0B]'
                              : 'bg-[#EF4444]'
                          }`}
                          style={{ width: `${Math.min((prodotto.giacenza / prodotto.minimoScorta) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(prodotto.stato)}`}>
                      {prodotto.stato}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#E5EAF2]">
          <div className="text-sm text-[#6B7280]">
            Mostrando <span className="font-medium text-[#2D2D2D]">{prodotti.length}</span> di <span className="font-medium text-[#2D2D2D]">{prodotti.length}</span> risultati
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Precedente
            </button>
            <button className="px-3 py-1.5 bg-[#17E88F] text-white rounded-lg font-medium text-sm">
              1
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              2
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Successivo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
