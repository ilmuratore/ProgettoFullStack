import {
  LayoutDashboard,
  Users,
  Building2,
  Package,
  Warehouse,
  ShoppingCart,
  TrendingUp,
  Truck,
  Receipt,
  ChevronDown,
  ChevronRight,
  Lock,
  UserCog,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react';
import { useState, useEffect } from 'react';

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  submenu?: { id: string; label: string }[];
}

interface SidebarProps {
  onNavigate?: (page: string) => void;
  activePage?: string;
  onCollapsedChange?: (collapsed: boolean) => void;
}

export function Sidebar({ onNavigate, activePage = 'dashboard', onCollapsedChange }: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);
  const [activeItem, setActiveItem] = useState(activePage);
  const [isCollapsed, setIsCollapsed] = useState(() => {
    const saved = localStorage.getItem('sidebar-collapsed');
    return saved === 'true';
  });

  useEffect(() => {
    localStorage.setItem('sidebar-collapsed', String(isCollapsed));
    onCollapsedChange?.(isCollapsed);
  }, [isCollapsed, onCollapsedChange]);

  const menuItems: MenuItem[] = [
    {
      id: 'admin',
      label: 'Admin',
      icon: <Lock className="w-5 h-5" />,
      submenu: [
        { id: 'azienda', label: 'Azienda' },
        { id: 'collaboratori', label: 'Collaboratori' },
      ]
    },
    {
      id: 'dashboard',
      label: 'Generale',
      icon: <LayoutDashboard className="w-5 h-5" />
    },
    {
      id: 'anagrafiche',
      label: 'Anagrafiche',
      icon: <Users className="w-5 h-5" />,
      submenu: [
        { id: 'clienti', label: 'Clienti' },
        { id: 'fornitori', label: 'Fornitori' },
        { id: 'prodotti', label: 'Prodotti' }
      ]
    },
    {
      id: 'magazzino',
      label: 'Magazzino',
      icon: <Warehouse className="w-5 h-5" />
    },
    {
      id: 'acquisti',
      label: 'Acquisti',
      icon: <ShoppingCart className="w-5 h-5" />
    },
    {
      id: 'vendite',
      label: 'Vendite',
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: 'logistica',
      label: 'Logistica',
      icon: <Truck className="w-5 h-5" />
    },
    {
      id: 'amministrazione',
      label: 'Amministrazione',
      icon: <Receipt className="w-5 h-5" />
    }
  ];

  const toggleMenu = (id: string) => {
    setExpandedMenus(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <aside className={`h-screen bg-white border-r border-[#E5EAF2] flex flex-col fixed left-0 top-0 transition-all duration-300 ${isCollapsed ? 'w-[72px]' : 'w-[260px]'}`}>
      <div className={`border-b border-[#E5EAF2] ${isCollapsed ? 'p-4' : 'p-6'}`}>
        <div className="flex items-center gap-3 justify-center">
          <div className="w-10 h-10 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-xl flex items-center justify-center flex-shrink-0">
            <Package className="w-6 h-6 text-white" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <h1 className="font-semibold text-[#2D2D2D]">LogiChain</h1>
              <p className="text-xs text-[#6B7280]">ERP System</p>
            </div>
          )}
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        {menuItems.map((item) => (
          <div key={item.id} className="relative group/menu">
            <button
              onClick={() => {
                if (item.submenu) {
                  if (item.id === 'anagrafiche') {
                    if (!expandedMenus.includes(item.id)) {
                      toggleMenu(item.id);
                    }
                    setActiveItem(item.id);
                    onNavigate?.(item.id);
                  } else if (item.id === 'admin') {
                    if (!isCollapsed) {
                      toggleMenu(item.id);
                    }
                  } else {
                    if (!isCollapsed) {
                      toggleMenu(item.id);
                    } else {
                      setActiveItem(item.id);
                      onNavigate?.(item.id);
                    }
                  }
                } else {
                  setActiveItem(item.id);
                  onNavigate?.(item.id);
                }
              }}
              className={`w-full flex items-center ${isCollapsed ? 'justify-center px-3 py-3' : 'justify-between px-4 py-3'} rounded-xl transition-all duration-200 group ${
                activeItem === item.id
                  ? 'bg-[#F0FDF7] text-[#17E88F] shadow-sm border-l-4 border-[#17E88F]'
                  : 'text-[#6B7280] hover:bg-[#F7F9FC] hover:text-[#2D2D2D]'
              }`}
            >
              <div className={`flex items-center ${isCollapsed ? '' : 'gap-3'}`}>
                <span className={activeItem === item.id ? 'text-[#17E88F]' : 'text-[#6B7280] group-hover:text-[#2D2D2D]'}>
                  {item.icon}
                </span>
                {!isCollapsed && <span className="font-medium">{item.label}</span>}
              </div>
              {!isCollapsed && item.submenu && (
                <span className="text-[#6B7280]">
                  {expandedMenus.includes(item.id) ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </span>
              )}
            </button>

            {isCollapsed && (
              <div className="absolute left-full ml-2 top-0 px-3 py-2 bg-[#2D2D2D] text-white text-sm rounded-lg opacity-0 pointer-events-none group-hover/menu:opacity-100 group-hover/menu:pointer-events-auto transition-opacity whitespace-nowrap z-50 shadow-xl">
                {item.label}
                <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-[#2D2D2D]"></div>
              </div>
            )}

            {!isCollapsed && item.submenu && expandedMenus.includes(item.id) && (
              <div className="ml-4 mt-1 space-y-1">
                {item.submenu.map((subitem) => (
                  <button
                    key={subitem.id}
                    onClick={() => {
                      setActiveItem(subitem.id);
                      onNavigate?.(subitem.id);
                    }}
                    className={`w-full flex items-center px-4 py-2 rounded-lg text-sm transition-all ${
                      activeItem === subitem.id
                        ? 'bg-[#F0FDF7] text-[#17E88F]'
                        : 'text-[#6B7280] hover:bg-[#F7F9FC] hover:text-[#2D2D2D]'
                    }`}
                  >
                    {subitem.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      <div className={`border-t border-[#E5EAF2] space-y-3 ${isCollapsed ? 'p-2' : 'p-4'}`}>
        {!isCollapsed && (
          <div className="flex items-center gap-2 text-xs text-[#6B7280] px-2">
            <div className="w-2 h-2 bg-[#22C55E] rounded-full animate-pulse" />
            <span>Sistema Online · 10:32</span>
          </div>
        )}

        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2' : 'gap-3 px-3 py-2'} rounded-xl hover:bg-[#F7F9FC] transition-all group/collapse relative`}
        >
          {isCollapsed ? (
            <ChevronsRight className="w-5 h-5 text-[#6B7280] group-hover/collapse:text-[#17E88F]" />
          ) : (
            <>
              <ChevronsLeft className="w-5 h-5 text-[#6B7280] group-hover/collapse:text-[#17E88F]" />
              <span className="text-sm font-medium text-[#6B7280] group-hover/collapse:text-[#2D2D2D]">Comprimi</span>
            </>
          )}
          {isCollapsed && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-3 py-2 bg-[#2D2D2D] text-white text-sm rounded-lg opacity-0 pointer-events-none group-hover/collapse:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-xl">
              Espandi
              <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-[#2D2D2D]"></div>
            </div>
          )}
        </button>

        <button
          onClick={() => { setActiveItem('profilo'); onNavigate?.('profilo'); }}
          className={`w-full flex items-center ${isCollapsed ? 'justify-center p-2' : 'gap-3 p-2'} rounded-xl hover:bg-[#F7F9FC] transition-colors group/profile relative`}
        >
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#17E88F] to-[#0FA67A] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            MR
          </div>
          {!isCollapsed && (
            <>
              <div className="flex-1 text-left min-w-0">
                <p className="text-xs font-medium text-[#2D2D2D] leading-none truncate">Marco Rossi</p>
                <p className="text-xs text-[#9CA3AF] mt-0.5 truncate">Admin</p>
              </div>
              <UserCog className="w-4 h-4 text-[#9CA3AF] opacity-0 group-hover/profile:opacity-100 transition-opacity" />
            </>
          )}
          {isCollapsed && (
            <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-3 py-2 bg-[#2D2D2D] text-white text-sm rounded-lg opacity-0 pointer-events-none group-hover/profile:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-xl">
              Marco Rossi
              <div className="absolute right-full top-1/2 -translate-y-1/2 border-4 border-transparent border-r-[#2D2D2D]"></div>
            </div>
          )}
        </button>
      </div>
    </aside>
  );
}
