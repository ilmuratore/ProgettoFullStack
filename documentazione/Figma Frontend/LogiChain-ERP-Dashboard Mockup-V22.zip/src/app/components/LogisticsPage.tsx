import { useState } from 'react';
import { Plus, Download, Filter } from 'lucide-react';
import { LogisticsKPIs } from './logistics/LogisticsKPIs';
import { ShipmentsTable } from './logistics/ShipmentsTable';
import { LogisticsWidgets } from './logistics/LogisticsWidgets';
import { DeliveryMap } from './logistics/DeliveryMap';
import { CourierPerformance } from './logistics/CourierPerformance';
import { LogisticsTimeline } from './logistics/LogisticsTimeline';
import { ScheduledDeliveries } from './logistics/ScheduledDeliveries';
import { ShipmentDrawer } from './logistics/ShipmentDrawer';
import { NewShipmentModal } from './logistics/NewShipmentModal';
import { AdvancedKPIs } from './logistics/AdvancedKPIs';

export function LogisticsPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedShipmentId, setSelectedShipmentId] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Logistica</h1>
          <p className="text-sm text-[#6B7280] mt-1">Dashboard / Logistica</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri Avanzati
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta Report
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium"
          >
            <Plus className="w-4 h-4" />
            Nuova Spedizione
          </button>
        </div>
      </div>

      {/* KPIs */}
      <LogisticsKPIs />

      {/* Main 70/30 Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-10 gap-6">
        <div className="lg:col-span-7">
          <ShipmentsTable onShipmentClick={setSelectedShipmentId} />
        </div>
        <div className="lg:col-span-3">
          <LogisticsWidgets />
        </div>
      </div>

      {/* Mappa Operativa */}
      <DeliveryMap />

      {/* Performance Corrieri */}
      <CourierPerformance />

      {/* Timeline e Consegne Programmate */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LogisticsTimeline />
        <ScheduledDeliveries />
      </div>

      {/* KPI Avanzati */}
      <AdvancedKPIs />

      {/* Drawer */}
      <ShipmentDrawer
        shipmentId={selectedShipmentId}
        isOpen={!!selectedShipmentId}
        onClose={() => setSelectedShipmentId(null)}
      />

      {/* Modal */}
      <NewShipmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}
