import { useState } from 'react';
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Mail,
  Phone,
  MapPin
} from 'lucide-react';

interface Fornitore {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  categoria: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

const fornitori: Fornitore[] = [
  { id: 1, ragioneSociale: 'Packaging Solutions Italia S.p.A.', codice: 'FOR-001', pIva: 'IT12345678901', citta: 'Milano', email: 'vendite@packagingsolutions.it', telefono: '+39 02 9876543', categoria: 'Imballaggi', stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Materiali Logistica Pro S.r.l.', codice: 'FOR-002', pIva: 'IT23456789012', citta: 'Bergamo', email: 'ordini@materialilogistica.it', telefono: '+39 035 1234567', categoria: 'Materiali', stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Pallet Systems Europe S.p.A.', codice: 'FOR-003', pIva: 'IT34567890123', citta: 'Brescia', email: 'info@palletsystems.it', telefono: '+39 030 7654321', categoria: 'Pallet', stato: 'Attivo' },
  { id: 4, ragioneSociale: 'Etichette Professionali S.r.l.', codice: 'FOR-004', pIva: 'IT45678901234', citta: 'Padova', email: 'commerciale@etichettepro.it', telefono: '+39 049 3698521', categoria: 'Etichette', stato: 'Attivo' },
  { id: 5, ragioneSociale: 'Film Protezione Italia S.p.A.', codice: 'FOR-005', pIva: 'IT56789012345', citta: 'Vicenza', email: 'vendite@filmprotezione.it', telefono: '+39 0444 258963', categoria: 'Film', stato: 'Sospeso' },
  { id: 6, ragioneSociale: 'Nastri & Reggette S.r.l.', codice: 'FOR-006', pIva: 'IT67890123456', citta: 'Treviso', email: 'info@nastrireggette.it', telefono: '+39 0422 147258', categoria: 'Nastri', stato: 'Attivo' },
  { id: 7, ragioneSociale: 'Scatole Cartone Europa S.p.A.', codice: 'FOR-007', pIva: 'IT78901234567', citta: 'Bologna', email: 'ordini@scatoleeuropa.it', telefono: '+39 051 9638527', categoria: 'Scatole', stato: 'Attivo' },
  { id: 8, ragioneSociale: 'Protezione Merci S.r.l.', codice: 'FOR-008', pIva: 'IT89012345678', citta: 'Modena', email: 'commerciale@protezionemerci.it', telefono: '+39 059 7418529', categoria: 'Protezione', stato: 'Attivo' },
];

export function FornitoriPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const getStatoBadgeColor = (stato: string) => {
    switch (stato) {
      case 'Attivo':
        return 'bg-[#DCFCE7] text-[#22C55E]';
      case 'Sospeso':
        return 'bg-[#FEF3C7] text-[#F59E0B]';
      case 'Inattivo':
        return 'bg-[#FEE2E2] text-[#EF4444]';
      default:
        return 'bg-[#F3F4F6] text-[#6B7280]';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-[#2D2D2D]">Fornitori</h1>
        <p className="text-sm text-[#6B7280] mt-1">Gestione anagrafica fornitori</p>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Importa
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta
          </button>
        </div>
        <button className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium">
          <Plus className="w-4 h-4" />
          Nuovo Fornitore
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cerca fornitori..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
            />
          </div>
          <button className="px-4 py-2 bg-[#F7F9FC] border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-white transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5EAF2]">
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {fornitori.map((fornitore, index) => (
                <tr
                  key={fornitore.id}
                  className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                    index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                  }`}
                >
                  <td className="py-3 px-4">
                    <div className="font-medium text-[#2D2D2D]">{fornitore.ragioneSociale}</div>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{fornitore.codice}</td>
                  <td className="py-3 px-4 text-sm text-[#6B7280]">{fornitore.pIva}</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                      <MapPin className="w-3 h-3" />
                      {fornitore.citta}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                        <Mail className="w-3 h-3" />
                        {fornitore.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                        <Phone className="w-3 h-3" />
                        {fornitore.telefono}
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                      {fornitore.categoria}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(fornitore.stato)}`}>
                      {fornitore.stato}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#DCFCE7] text-[#22C55E] rounded-lg transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#FEE2E2] text-[#EF4444] rounded-lg transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#E5EAF2]">
          <div className="text-sm text-[#6B7280]">
            Mostrando <span className="font-medium text-[#2D2D2D]">{fornitori.length}</span> di <span className="font-medium text-[#2D2D2D]">{fornitori.length}</span> risultati
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Precedente
            </button>
            <button className="px-3 py-1.5 bg-[#17E88F] text-white rounded-lg font-medium text-sm">
              1
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              2
            </button>
            <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
              Successivo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
