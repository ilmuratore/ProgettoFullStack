import { Users, Building2, Package, TrendingUp, AlertTriangle, Clock } from 'lucide-react';
import { KPICard } from './KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const categoriesData = [
  { name: 'Pallet', value: 4, color: '#3B82F6' },
  { name: 'Scatole', value: 8, color: '#17E88F' },
  { name: 'Etichette', value: 6, color: '#F59E0B' },
  { name: 'Film', value: 3, color: '#8B5CF6' },
  { name: 'Protezione', value: 5, color: '#EF4444' },
];

const topFornitori = [
  { nome: 'Pallet Systems Europe S.p.A.', ordini: 145, valore: '€ 125.000' },
  { nome: 'Scatole Cartone Europa S.p.A.', ordini: 132, valore: '€ 98.500' },
  { nome: 'Etichette Professionali S.r.l.', ordini: 98, valore: '€ 87.200' },
  { nome: 'Film Protezione Italia S.p.A.', ordini: 76, valore: '€ 72.100' },
];

const topClienti = [
  { nome: 'Supply Chain Pro S.r.l.', fatturato: '€ 1.450.000' },
  { nome: 'Transport Solutions S.p.A.', fatturato: '€ 1.200.000' },
  { nome: 'Cargo Italia S.p.A.', fatturato: '€ 975.000' },
  { nome: 'Spedizioni Rapide S.r.l.', fatturato: '€ 890.000' },
];

const prodottiSottoScorta = [
  { sku: 'FLM-EST-012', nome: 'Film Estensibile Trasparente 50cm', giacenza: 12, minimo: 50 },
  { sku: 'NST-AVA-056', nome: 'Nastro Adesivo Avana 50mm', giacenza: 8, minimo: 30 },
  { sku: 'ETI-TRM-112', nome: 'Etichette Termiche 100x150mm', giacenza: 0, minimo: 100 },
];

const recentActivities = [
  { tipo: 'Cliente', descrizione: 'Nuovo cliente "Logistica Express S.r.l." aggiunto', timestamp: '2 ore fa', icon: Users },
  { tipo: 'Fornitore', descrizione: 'Aggiornato lead time per "Pallet Systems Europe"', timestamp: '4 ore fa', icon: Building2 },
  { tipo: 'Prodotto', descrizione: 'Nuovo prodotto "Pallet in Plastica" creato', timestamp: '6 ore fa', icon: Package },
  { tipo: 'Cliente', descrizione: 'Cliente "Transport Solutions" aggiornato', timestamp: '1 giorno fa', icon: Users },
];

export function AnagraficheOverview() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-[#2D2D2D]">Anagrafiche</h1>
        <p className="text-sm text-[#6B7280] mt-1">Panoramica generale di clienti, fornitori e prodotti</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-[#6B7280]">Clienti</h3>
            <p className="text-3xl font-semibold text-[#2D2D2D]">127</p>
            <div className="flex items-center gap-4 text-sm">
              <div>
                <span className="text-[#6B7280]">Attivi: </span>
                <span className="font-medium text-[#22C55E]">118</span>
              </div>
              <div>
                <span className="text-[#6B7280]">Nuovi: </span>
                <span className="font-medium text-[#17E88F]">+12</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-[#6B7280]">Fornitori</h3>
            <p className="text-3xl font-semibold text-[#2D2D2D]">54</p>
            <div className="flex items-center gap-4 text-sm">
              <div>
                <span className="text-[#6B7280]">Attivi: </span>
                <span className="font-medium text-[#22C55E]">52</span>
              </div>
              <div>
                <span className="text-[#6B7280]">Lead Time: </span>
                <span className="font-medium text-[#2D2D2D]">7.2gg</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-xl flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-[#6B7280]">Prodotti</h3>
            <p className="text-3xl font-semibold text-[#2D2D2D]">342</p>
            <div className="flex items-center gap-4 text-sm">
              <div>
                <span className="text-[#6B7280]">Attivi: </span>
                <span className="font-medium text-[#22C55E]">315</span>
              </div>
              <div>
                <span className="text-[#6B7280]">Sotto scorta: </span>
                <span className="font-medium text-[#EF4444]">3</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-[#2D2D2D]">Distribuzione Prodotti per Categoria</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoriesData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoriesData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-[#2D2D2D]">Top Fornitori per Volume Ordini</h3>
          </div>
          <div className="space-y-4">
            {topFornitori.map((fornitore, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#2D2D2D]">{fornitore.nome}</p>
                  <p className="text-xs text-[#6B7280] mt-0.5">{fornitore.ordini} ordini</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-[#17E88F]">{fornitore.valore}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-[#2D2D2D]">Top Clienti per Fatturato</h3>
          </div>
          <div className="space-y-4">
            {topClienti.map((cliente, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-[#F7F9FC] rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-[#3B82F6] to-[#2563EB] rounded-lg flex items-center justify-center text-white font-bold text-xs">
                    {index + 1}
                  </div>
                  <p className="text-sm font-medium text-[#2D2D2D]">{cliente.nome}</p>
                </div>
                <p className="text-sm font-semibold text-[#17E88F]">{cliente.fatturato}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-[#2D2D2D]">Prodotti Sotto Scorta</h3>
            <span className="px-3 py-1 bg-[#FEE2E2] text-[#EF4444] rounded-lg text-xs font-medium">
              {prodottiSottoScorta.length} Critici
            </span>
          </div>
          <div className="space-y-3">
            {prodottiSottoScorta.map((prodotto, index) => (
              <div key={index} className="p-3 bg-[#FEF3F3] border border-[#FEE2E2] rounded-xl">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-[#2D2D2D]">{prodotto.nome}</p>
                    <p className="text-xs text-[#6B7280] font-mono mt-0.5">{prodotto.sku}</p>
                  </div>
                  <AlertTriangle className="w-4 h-4 text-[#EF4444] flex-shrink-0" />
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-[#6B7280]">Giacenza:</span>
                  <span className="font-semibold text-[#EF4444]">{prodotto.giacenza} pz</span>
                  <span className="text-[#9CA3AF]">/</span>
                  <span className="text-[#6B7280]">Min: {prodotto.minimo}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-[#2D2D2D]">Ultime Attività Anagrafiche</h3>
        </div>
        <div className="space-y-3">
          {recentActivities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div key={index} className="flex items-center gap-4 p-3 hover:bg-[#F7F9FC] rounded-xl transition-all">
                <div className="w-10 h-10 bg-[#F7F9FC] rounded-xl flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-[#6B7280]" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#2D2D2D]">{activity.descrizione}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs px-2 py-0.5 bg-[#EEF2FF] text-[#6366F1] rounded-lg font-medium">
                      {activity.tipo}
                    </span>
                    <span className="text-xs text-[#9CA3AF]">{activity.timestamp}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
