import { useState, useRef, useEffect } from 'react';
import { Search, ChevronRight, LogOut, User, Shield, BellRing, Settings, FileText, HelpCircle, ChevronDown } from 'lucide-react';
import { GlobalSearch } from './GlobalSearch';
import { NotificationsPanel } from './NotificationsPanel';

interface HeaderProps {
  onNavigate?: (page: string) => void;
  sidebarCollapsed?: boolean;
}

const dropdownItems = [
  { icon: User, label: 'Il Mio Profilo', page: 'amministrazione', color: 'text-[#3B82F6]', bg: 'bg-[#DBEAFE]' },
  { icon: Shield, label: 'Sicurezza', page: null, color: 'text-[#F59E0B]', bg: 'bg-[#FEF3C7]' },
  { icon: BellRing, label: 'Notifiche', page: null, color: 'text-[#8B5CF6]', bg: 'bg-[#EDE9FE]' },
  { icon: Settings, label: 'Preferenze', page: null, color: 'text-[#6B7280]', bg: 'bg-[#F3F4F6]' },
  { icon: FileText, label: 'Attività Recenti', page: null, color: 'text-[#17E88F]', bg: 'bg-[#F0FDF7]' },
  { icon: HelpCircle, label: 'Supporto', page: null, color: 'text-[#6B7280]', bg: 'bg-[#F3F4F6]' },
];

export function Header({ onNavigate, sidebarCollapsed = false }: HeaderProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      <header className={`h-16 bg-white/80 backdrop-blur-sm border-b border-[#E5EAF2] fixed top-0 right-0 z-10 transition-all duration-300 ${sidebarCollapsed ? 'left-[72px]' : 'left-[260px]'}`}>
        <div className="h-full px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <h2 className="font-semibold text-[#2D2D2D]">Dashboard Operativa</h2>
              <div className="flex items-center gap-2 text-sm text-[#6B7280] mt-0.5">
                <span>Home</span>
                <ChevronRight className="w-3 h-3" />
                <span className="text-[#17E88F]">Dashboard</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
          <button
            onClick={() => setSearchOpen(true)}
            className="relative w-64 h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl hover:border-[#17E88F] transition-all text-left group"
          >
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2 group-hover:text-[#17E88F]" />
            <span className="text-sm text-[#9CA3AF]">Cerca...</span>
            <kbd className="absolute right-3 top-1/2 -translate-y-1/2 px-2 py-0.5 text-xs font-mono bg-white text-[#6B7280] rounded border border-[#E5EAF2]">
              ⌘K
            </kbd>
          </button>

          <NotificationsPanel onNavigate={onNavigate} />

          <div className="h-8 w-px bg-[#E5EAF2]" />

          {/* User dropdown trigger */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen(prev => !prev)}
              className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-[#F7F9FC] transition-all group"
            >
              <div className="text-right">
                <div className="font-medium text-sm text-[#2D2D2D]">Mario Rossi</div>
                <div className="text-xs text-[#6B7280]">Responsabile Logistica</div>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-xl flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-white" />
              </div>
              <ChevronDown className={`w-4 h-4 text-[#9CA3AF] transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {dropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-[#E5EAF2] overflow-hidden z-50">
                {/* Profile header */}
                <div className="p-4 bg-gradient-to-br from-[#F0FDF7] to-[#F7F9FC] border-b border-[#E5EAF2]">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md">
                      <User className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[#2D2D2D]">Mario Rossi</p>
                      <p className="text-xs text-[#6B7280] mt-0.5">Responsabile Logistica</p>
                      <p className="text-xs text-[#9CA3AF] truncate">mario.rossi@logichain.it</p>
                      <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 bg-[#DCFCE7] text-[#16A34A] rounded-full text-xs font-medium">
                        <span className="w-1.5 h-1.5 bg-[#22C55E] rounded-full" />
                        Attivo
                      </span>
                    </div>
                  </div>
                </div>

                {/* Menu items */}
                <div className="p-2">
                  {dropdownItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.label}
                        onClick={() => {
                          setDropdownOpen(false);
                          if (item.page) onNavigate?.(item.page);
                        }}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-[#F7F9FC] transition-colors text-left group"
                      >
                        <div className={`w-8 h-8 ${item.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          <Icon className={`w-4 h-4 ${item.color}`} />
                        </div>
                        <span className="text-sm font-medium text-[#2D2D2D] group-hover:text-[#2D2D2D]">{item.label}</span>
                        <ChevronRight className="w-3.5 h-3.5 text-[#9CA3AF] ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    );
                  })}
                </div>

                {/* Logout */}
                <div className="p-2 border-t border-[#E5EAF2]">
                  <button
                    onClick={() => setDropdownOpen(false)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-[#FEE2E2] transition-colors text-left group"
                  >
                    <div className="w-8 h-8 bg-[#FEE2E2] rounded-lg flex items-center justify-center flex-shrink-0 group-hover:bg-[#FECACA]">
                      <LogOut className="w-4 h-4 text-[#EF4444]" />
                    </div>
                    <span className="text-sm font-medium text-[#EF4444]">Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>
          </div>
        </div>
      </header>

      {searchOpen && <GlobalSearch onNavigate={onNavigate} onClose={() => setSearchOpen(false)} />}
    </>
  );
}
