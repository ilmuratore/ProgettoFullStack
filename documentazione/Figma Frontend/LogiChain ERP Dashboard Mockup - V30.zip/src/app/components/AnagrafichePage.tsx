import { useState } from 'react';
import {
  Search,
  Plus,
  Download,
  Upload,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
  Mail,
  Phone,
  MapPin,
  Building2,
  Package,
  User,
  Truck,
  Users,
  ChevronRight
} from 'lucide-react';
import { PageTabBar } from './ui/PageTabBar';

type TabType = 'prodotti' | 'categorie' | 'fornitori' | 'clienti' | 'corrieri' | 'dipendenti';

interface Cliente {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  fatturato: string;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

interface Fornitore {
  id: number;
  ragioneSociale: string;
  codice: string;
  pIva: string;
  citta: string;
  email: string;
  telefono: string;
  categoria: string;
  leadTime: number;
  stato: 'Attivo' | 'Sospeso' | 'Inattivo';
}

interface Prodotto {
  id: number;
  nome: string;
  sku: string;
  categoria: string;
  fornitore: string;
  prezzo: string;
  giacenza: number;
  minimoScorta: number;
  stato: 'Disponibile' | 'Esaurito' | 'In Arrivo';
}

interface Categoria {
  id: number;
  nome: string;
  padre: string | null;
  prodottiCount: number;
}

interface Corriere {
  id: number;
  nome: string;
  codice: string;
  email: string;
  telefono: string;
  spedizioniAttive: number;
  stato: 'Attivo' | 'Sospeso';
}

interface Dipendente {
  id: number;
  nome: string;
  cognome: string;
  cf: string;
  ruolo: string;
  email: string;
  telefono: string;
  utenteCollegato: boolean;
  stato: 'Attivo' | 'Sospeso';
}

const clienti: Cliente[] = [
  { id: 1, ragioneSociale: 'Logistica Express S.r.l.', codice: 'CLI-001', pIva: 'IT02345678901', citta: 'Milano', email: 'info@logisticaexpress.it', telefono: '+39 02 1234567', fatturato: '€ 850.000', stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Transport Solutions S.p.A.', codice: 'CLI-002', pIva: 'IT03456789012', citta: 'Roma', email: 'contact@transportsolutions.it', telefono: '+39 06 7654321', fatturato: '€ 1.200.000', stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Supply Chain Pro S.r.l.', codice: 'CLI-006', pIva: 'IT07890123456', citta: 'Firenze', email: 'contact@supplychainpro.it', telefono: '+39 055 1357924', fatturato: '€ 1.450.000', stato: 'Attivo' },
];

const fornitori: Fornitore[] = [
  { id: 1, ragioneSociale: 'Packaging Solutions Italia S.p.A.', codice: 'FOR-001', pIva: 'IT12345678901', citta: 'Milano', email: 'vendite@packagingsolutions.it', telefono: '+39 02 9876543', categoria: 'Imballaggi', leadTime: 7, stato: 'Attivo' },
  { id: 2, ragioneSociale: 'Pallet Systems Europe S.p.A.', codice: 'FOR-003', pIva: 'IT34567890123', citta: 'Brescia', email: 'info@palletsystems.it', telefono: '+39 030 7654321', categoria: 'Pallet', leadTime: 5, stato: 'Attivo' },
  { id: 3, ragioneSociale: 'Etichette Professionali S.r.l.', codice: 'FOR-004', pIva: 'IT45678901234', citta: 'Padova', email: 'commerciale@etichettepro.it', telefono: '+39 049 3698521', categoria: 'Etichette', leadTime: 10, stato: 'Attivo' },
];

const prodotti: Prodotto[] = [
  { id: 1, nome: 'Pallet Standard EUR 1200x800', sku: 'PLT-EUR-001', categoria: 'Pallet', fornitore: 'Pallet Systems Europe', prezzo: '€ 12,50', giacenza: 450, minimoScorta: 200, stato: 'Disponibile' },
  { id: 2, nome: 'Scatola Cartone Ondulato 40x30x30', sku: 'SCT-OND-045', categoria: 'Scatole', fornitore: 'Scatole Cartone Europa', prezzo: '€ 0,85', giacenza: 2500, minimoScorta: 1000, stato: 'Disponibile' },
  { id: 3, nome: 'Film Estensibile Trasparente 50cm', sku: 'FLM-EST-012', categoria: 'Film', fornitore: 'Film Protezione Italia', prezzo: '€ 18,90', giacenza: 12, minimoScorta: 50, stato: 'Esaurito' },
];

const categorie: Categoria[] = [
  { id: 1, nome: 'Pallet', padre: null, prodottiCount: 15 },
  { id: 2, nome: 'Pallet Legno', padre: 'Pallet', prodottiCount: 8 },
  { id: 3, nome: 'Pallet Plastica', padre: 'Pallet', prodottiCount: 7 },
  { id: 4, nome: 'Scatole', padre: null, prodottiCount: 24 },
  { id: 5, nome: 'Scatole Cartone', padre: 'Scatole', prodottiCount: 18 },
  { id: 6, nome: 'Scatole Plastica', padre: 'Scatole', prodottiCount: 6 },
];

const corrieri: Corriere[] = [
  { id: 1, nome: 'BRT Express', codice: 'BRT', email: 'operativo@brt.it', telefono: '+39 02 123456', spedizioniAttive: 45, stato: 'Attivo' },
  { id: 2, nome: 'GLS Logistics', codice: 'GLS', email: 'servizio@gls.it', telefono: '+39 06 654321', spedizioniAttive: 32, stato: 'Attivo' },
  { id: 3, nome: 'DHL Italia', codice: 'DHL', email: 'italy@dhl.com', telefono: '+39 011 987654', spedizioniAttive: 28, stato: 'Attivo' },
];

const dipendenti: Dipendente[] = [
  { id: 1, nome: 'Marco', cognome: 'Rossi', cf: 'RSSMRC85M01F205W', ruolo: 'Resp. Magazzino', email: 'marco.rossi@logichain.it', telefono: '+39 333 1234567', utenteCollegato: true, stato: 'Attivo' },
  { id: 2, nome: 'Laura', cognome: 'Bianchi', cf: 'BNCLRA90H41F205X', ruolo: 'Operatore', email: 'laura.bianchi@logichain.it', telefono: '+39 333 2345678', utenteCollegato: true, stato: 'Attivo' },
  { id: 3, nome: 'Giuseppe', cognome: 'Verdi', cf: 'VRDGPP88A01F205Y', ruolo: 'Operatore', email: 'giuseppe.verdi@logichain.it', telefono: '+39 333 3456789', utenteCollegato: false, stato: 'Attivo' },
];

export function AnagrafichePage() {
  const [activeTab, setActiveTab] = useState<TabType>('prodotti');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'prodotti' as TabType, label: 'Prodotti', icon: Package, count: prodotti.length },
    { id: 'categorie' as TabType, label: 'Categorie', icon: Building2, count: categorie.filter(c => !c.padre).length },
    { id: 'fornitori' as TabType, label: 'Fornitori', icon: Building2, count: fornitori.length },
    { id: 'clienti' as TabType, label: 'Clienti', icon: User, count: clienti.length },
    { id: 'corrieri' as TabType, label: 'Corrieri', icon: Truck, count: corrieri.length },
    { id: 'dipendenti' as TabType, label: 'Dipendenti', icon: Users, count: dipendenti.length },
  ];

  const getStatoBadgeColor = (stato: string) => {
    switch (stato) {
      case 'Attivo':
      case 'Disponibile':
        return 'bg-[#DCFCE7] text-[#16A34A]';
      case 'Sospeso':
      case 'In Arrivo':
        return 'bg-[#FEF3C7] text-[#D97706]';
      case 'Inattivo':
      case 'Esaurito':
        return 'bg-[#FEE2E2] text-[#DC2626]';
      default:
        return 'bg-[#F3F4F6] text-[#6B7280]';
    }
  };

  const getNewButtonLabel = () => {
    switch (activeTab) {
      case 'prodotti': return 'Nuovo Prodotto';
      case 'categorie': return 'Nuova Categoria';
      case 'fornitori': return 'Nuovo Fornitore';
      case 'clienti': return 'Nuovo Cliente';
      case 'corrieri': return 'Nuovo Corriere';
      case 'dipendenti': return 'Nuovo Dipendente';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#2D2D2D]">Gestione Anagrafiche</h1>
          <p className="text-sm text-[#6B7280] mt-1">Gestisci clienti, fornitori, prodotti e dipendenti</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Upload className="w-4 h-4" />
            Importa
          </button>
          <button className="px-4 py-2 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-[#F7F9FC] transition-all flex items-center gap-2">
            <Download className="w-4 h-4" />
            Esporta
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-[#17E88F] to-[#0FA67A] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2 font-medium">
            <Plus className="w-4 h-4" />
            {getNewButtonLabel()}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-[#E5EAF2] overflow-hidden">
        <PageTabBar tabs={tabs} activeTab={activeTab} onTabChange={(id) => setActiveTab(id as TabType)} />

        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={`Cerca ${activeTab}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
              />
            </div>
            <button className="px-4 py-2 bg-[#F7F9FC] border border-[#E5EAF2] text-[#6B7280] rounded-xl hover:bg-white transition-all flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Filtri
            </button>
          </div>

          {/* TAB PRODOTTI */}
          {activeTab === 'prodotti' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5EAF2]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Nome Prodotto</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">SKU</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fornitore</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Prezzo</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Giacenza</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {prodotti.map((prodotto, index) => (
                    <tr
                      key={prodotto.id}
                      className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#2D2D2D]">{prodotto.nome}</div>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{prodotto.sku}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                          {prodotto.categoria}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280]">{prodotto.fornitore}</td>
                      <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{prodotto.prezzo}</td>
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          <div className="text-sm font-medium text-[#2D2D2D]">{prodotto.giacenza} pz</div>
                          <div className="text-xs text-[#6B7280]">Min: {prodotto.minimoScorta}</div>
                          <div className="w-full h-1.5 bg-[#F3F4F6] rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all ${
                                prodotto.giacenza > prodotto.minimoScorta
                                  ? 'bg-[#16A34A]'
                                  : prodotto.giacenza > 0
                                  ? 'bg-[#D97706]'
                                  : 'bg-[#DC2626]'
                              }`}
                              style={{ width: `${Math.min((prodotto.giacenza / prodotto.minimoScorta) * 100, 100)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(prodotto.stato)}`}>
                          {prodotto.stato}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB CATEGORIE */}
          {activeTab === 'categorie' && (
            <div className="space-y-4">
              {categorie.filter(c => !c.padre).map((categoria) => (
                <div key={categoria.id} className="border border-[#E5EAF2] rounded-xl overflow-hidden">
                  <div className="flex items-center justify-between p-4 bg-[#F7F9FC]">
                    <div className="flex items-center gap-3">
                      <ChevronRight className="w-5 h-5 text-[#6B7280]" />
                      <div>
                        <h3 className="font-semibold text-[#2D2D2D]">{categoria.nome}</h3>
                        <p className="text-xs text-[#6B7280] mt-0.5">{categoria.prodottiCount} prodotti totali</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  {categorie.filter(c => c.padre === categoria.nome).map((subcat) => (
                    <div key={subcat.id} className="flex items-center justify-between p-3 px-6 border-t border-[#E5EAF2] hover:bg-[#F7F9FC] transition-all">
                      <div className="flex items-center gap-3">
                        <div className="w-1 h-8 bg-[#E5EAF2] rounded" />
                        <div>
                          <p className="text-sm font-medium text-[#2D2D2D]">{subcat.nome}</p>
                          <p className="text-xs text-[#6B7280]">{subcat.prodottiCount} prodotti</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {/* TAB FORNITORI */}
          {activeTab === 'fornitori' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5EAF2]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Lead Time</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Categoria</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {fornitori.map((fornitore, index) => (
                    <tr
                      key={fornitore.id}
                      className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#2D2D2D]">{fornitore.ragioneSociale}</div>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{fornitore.codice}</td>
                      <td className="py-3 px-4 text-sm text-[#6B7280]">{fornitore.pIva}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                          <MapPin className="w-3 h-3" />
                          {fornitore.citta}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Mail className="w-3 h-3" />
                            {fornitore.email}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Phone className="w-3 h-3" />
                            {fornitore.telefono}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#DBEAFE] text-[#1D4ED8]">
                          {fornitore.leadTime} giorni
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                          {fornitore.categoria}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(fornitore.stato)}`}>
                          {fornitore.stato}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB CLIENTI */}
          {activeTab === 'clienti' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5EAF2]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ragione Sociale</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">P. IVA</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Città</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Fatturato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {clienti.map((cliente, index) => (
                    <tr
                      key={cliente.id}
                      className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#2D2D2D]">{cliente.ragioneSociale}</div>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{cliente.codice}</td>
                      <td className="py-3 px-4 text-sm text-[#6B7280]">{cliente.pIva}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                          <MapPin className="w-3 h-3" />
                          {cliente.citta}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Mail className="w-3 h-3" />
                            {cliente.email}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Phone className="w-3 h-3" />
                            {cliente.telefono}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm font-medium text-[#2D2D2D]">{cliente.fatturato}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(cliente.stato)}`}>
                          {cliente.stato}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB CORRIERI */}
          {activeTab === 'corrieri' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5EAF2]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Nome</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Email</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Telefono</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Spedizioni Attive</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {corrieri.map((corriere, index) => (
                    <tr
                      key={corriere.id}
                      className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#2D2D2D]">{corriere.nome}</div>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{corriere.codice}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                          <Mail className="w-3 h-3" />
                          {corriere.email}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 text-sm text-[#6B7280]">
                          <Phone className="w-3 h-3" />
                          {corriere.telefono}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#DBEAFE] text-[#3B82F6]">
                          {corriere.spedizioniAttive} attive
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(corriere.stato)}`}>
                          {corriere.stato}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB DIPENDENTI */}
          {activeTab === 'dipendenti' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5EAF2]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Nome Completo</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Codice Fiscale</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Ruolo</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Contatti</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Utente Sistema</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Stato</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-[#6B7280]">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {dipendenti.map((dipendente, index) => (
                    <tr
                      key={dipendente.id}
                      className={`border-b border-[#E5EAF2] hover:bg-[#F7F9FC] transition-colors ${
                        index % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#2D2D2D]">{dipendente.nome} {dipendente.cognome}</div>
                      </td>
                      <td className="py-3 px-4 text-sm text-[#6B7280] font-mono">{dipendente.cf}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#EEF2FF] text-[#6366F1]">
                          {dipendente.ruolo}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Mail className="w-3 h-3" />
                            {dipendente.email}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                            <Phone className="w-3 h-3" />
                            {dipendente.telefono}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {dipendente.utenteCollegato ? (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#DCFCE7] text-[#16A34A]">
                            Collegato
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-[#F3F4F6] text-[#6B7280]">
                            Non collegato
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${getStatoBadgeColor(dipendente.stato)}`}>
                          {dipendente.stato}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 hover:bg-[#DBEAFE] text-[#3B82F6] rounded-lg transition-all">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#DCFCE7] text-[#16A34A] rounded-lg transition-all">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#FEE2E2] text-[#DC2626] rounded-lg transition-all">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 hover:bg-[#F7F9FC] text-[#6B7280] rounded-lg transition-all">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#E5EAF2]">
            <div className="text-sm text-[#6B7280]">
              Mostrando <span className="font-medium text-[#2D2D2D]">
                {activeTab === 'clienti' ? clienti.length :
                 activeTab === 'fornitori' ? fornitori.length :
                 activeTab === 'prodotti' ? prodotti.length :
                 activeTab === 'categorie' ? categorie.filter(c => !c.padre).length :
                 activeTab === 'corrieri' ? corrieri.length :
                 dipendenti.length}
              </span> risultati
            </div>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
                Precedente
              </button>
              <button className="px-3 py-1.5 bg-[#17E88F] text-white rounded-lg font-medium text-sm">
                1
              </button>
              <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
                2
              </button>
              <button className="px-3 py-1.5 bg-white border border-[#E5EAF2] text-[#6B7280] rounded-lg hover:bg-[#F7F9FC] transition-all text-sm">
                Successivo
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
