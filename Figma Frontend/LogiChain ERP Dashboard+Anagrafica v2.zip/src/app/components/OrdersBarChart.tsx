import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'Ricevuti', value: 245, color: '#17E88F' },
  { name: 'Confermati', value: 189, color: '#22C55E' },
  { name: 'In Elaborazione', value: 128, color: '#3B82F6' },
  { name: 'Completati', value: 412, color: '#0FA67A' },
  { name: 'Annullati', value: 23, color: '#EF4444' },
];

export function OrdersBarChart() {
  return (
    <div className="bg-white rounded-2xl p-6 border border-[#E5EAF2] h-full">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-semibold text-[#2D2D2D]">Ordini in Entrata per Stato</h3>
        <div className="text-xs text-[#6B7280]">Ultimi 30 giorni</div>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <defs>
            {data.map((entry, index) => (
              <linearGradient key={index} id={`colorGradient${index}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={entry.color} stopOpacity={1} />
                <stop offset="100%" stopColor={entry.color} stopOpacity={0.7} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5EAF2" vertical={false} />
          <XAxis
            dataKey="name"
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <Tooltip
            cursor={{ fill: '#F7F9FC' }}
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #E5EAF2',
              borderRadius: '12px',
              padding: '8px 12px',
              boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
            }}
          />
          <Bar dataKey="value" radius={[8, 8, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={`url(#colorGradient${index})`} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
