import { Search, Bell, ChevronRight, LogOut, User } from 'lucide-react';

export function Header() {
  return (
    <header className="h-16 bg-white/80 backdrop-blur-sm border-b border-[#E5EAF2] fixed top-0 right-0 left-[260px] z-10">
      <div className="h-full px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div>
            <h2 className="font-semibold text-[#2D2D2D]">Dashboard Operativa</h2>
            <div className="flex items-center gap-2 text-sm text-[#6B7280] mt-0.5">
              <span>Home</span>
              <ChevronRight className="w-3 h-3" />
              <span className="text-[#17E88F]">Dashboard</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cerca..."
              className="w-64 h-10 pl-10 pr-4 bg-[#F7F9FC] border border-[#E5EAF2] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#17E88F]/20 focus:border-[#17E88F] transition-all"
            />
          </div>

          <button className="relative p-2 hover:bg-[#F7F9FC] rounded-xl transition-all">
            <Bell className="w-5 h-5 text-[#6B7280]" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#EF4444] rounded-full ring-2 ring-white" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#EF4444] text-white text-xs rounded-full flex items-center justify-center font-medium">
              7
            </span>
          </button>

          <div className="h-8 w-px bg-[#E5EAF2]" />

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="font-medium text-sm text-[#2D2D2D]">Mario Rossi</div>
              <div className="text-xs text-[#6B7280]">Responsabile Logistica</div>
            </div>
            <div className="w-10 h-10 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-xl flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
          </div>

          <button className="p-2 hover:bg-[#F7F9FC] rounded-xl transition-all group">
            <LogOut className="w-5 h-5 text-[#6B7280] group-hover:text-[#EF4444]" />
          </button>
        </div>
      </div>
    </header>
  );
}
