import {
  LayoutDashboard,
  Users,
  Building2,
  Package,
  Warehouse,
  ShoppingCart,
  TrendingUp,
  Truck,
  Receipt,
  ChevronDown,
  ChevronRight,
  Lock,
  UserCog
} from 'lucide-react';
import { useState } from 'react';

interface MenuItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  submenu?: { id: string; label: string }[];
}

interface SidebarProps {
  onNavigate?: (page: string) => void;
  activePage?: string;
}

export function Sidebar({ onNavigate, activePage = 'dashboard' }: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);
  const [activeItem, setActiveItem] = useState(activePage);

  const menuItems: MenuItem[] = [
    {
      id: 'admin',
      label: 'Admin',
      icon: <Lock className="w-5 h-5" />,
      submenu: [
        { id: 'azienda', label: 'Azienda' },
        { id: 'collaboratori', label: 'Collaboratori' },
      ]
    },
    {
      id: 'dashboard',
      label: 'Generale',
      icon: <LayoutDashboard className="w-5 h-5" />
    },
    {
      id: 'anagrafiche',
      label: 'Anagrafiche',
      icon: <Users className="w-5 h-5" />,
      submenu: [
        { id: 'clienti', label: 'Clienti' },
        { id: 'fornitori', label: 'Fornitori' },
        { id: 'prodotti', label: 'Prodotti' }
      ]
    },
    {
      id: 'magazzino',
      label: 'Magazzino',
      icon: <Warehouse className="w-5 h-5" />
    },
    {
      id: 'acquisti',
      label: 'Acquisti',
      icon: <ShoppingCart className="w-5 h-5" />
    },
    {
      id: 'vendite',
      label: 'Vendite',
      icon: <TrendingUp className="w-5 h-5" />
    },
    {
      id: 'logistica',
      label: 'Logistica',
      icon: <Truck className="w-5 h-5" />
    },
    {
      id: 'amministrazione',
      label: 'Amministrazione',
      icon: <Receipt className="w-5 h-5" />
    }
  ];

  const toggleMenu = (id: string) => {
    setExpandedMenus(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <aside className="w-[260px] h-screen bg-white border-r border-[#E5EAF2] flex flex-col fixed left-0 top-0">
      <div className="p-6 border-b border-[#E5EAF2]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#17E88F] to-[#0FA67A] rounded-xl flex items-center justify-center">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-semibold text-[#2D2D2D]">LogiChain</h1>
            <p className="text-xs text-[#6B7280]">ERP System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        {menuItems.map((item) => (
          <div key={item.id}>
            <button
              onClick={() => {
                if (item.submenu) {
                  toggleMenu(item.id);
                } else {
                  setActiveItem(item.id);
                  onNavigate?.(item.id);
                }
              }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group ${
                activeItem === item.id
                  ? 'bg-[#F0FDF7] text-[#17E88F] shadow-sm border-l-4 border-[#17E88F]'
                  : 'text-[#6B7280] hover:bg-[#F7F9FC] hover:text-[#2D2D2D]'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={activeItem === item.id ? 'text-[#17E88F]' : 'text-[#6B7280] group-hover:text-[#2D2D2D]'}>
                  {item.icon}
                </span>
                <span className="font-medium">{item.label}</span>
              </div>
              {item.submenu && (
                <span className="text-[#6B7280]">
                  {expandedMenus.includes(item.id) ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </span>
              )}
            </button>

            {item.submenu && expandedMenus.includes(item.id) && (
              <div className="ml-4 mt-1 space-y-1">
                {item.submenu.map((subitem) => (
                  <button
                    key={subitem.id}
                    onClick={() => {
                      setActiveItem(subitem.id);
                      if (item.id === 'admin') {
                        onNavigate?.(subitem.id);
                      } else {
                        onNavigate?.(item.id);
                      }
                    }}
                    className={`w-full flex items-center px-4 py-2 rounded-lg text-sm transition-all ${
                      activeItem === subitem.id
                        ? 'bg-[#F0FDF7] text-[#17E88F]'
                        : 'text-[#6B7280] hover:bg-[#F7F9FC] hover:text-[#2D2D2D]'
                    }`}
                  >
                    {subitem.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      <div className="p-4 border-t border-[#E5EAF2] space-y-3">
        <div className="flex items-center gap-2 text-xs text-[#6B7280]">
          <div className="w-2 h-2 bg-[#22C55E] rounded-full animate-pulse" />
          <span>Sistema Online · 10:32</span>
        </div>
        <button
          onClick={() => { setActiveItem('profilo'); onNavigate?.('profilo'); }}
          className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#F7F9FC] transition-colors group"
        >
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#17E88F] to-[#0FA67A] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
            MR
          </div>
          <div className="flex-1 text-left">
            <p className="text-xs font-medium text-[#2D2D2D] leading-none">Marco Rossi</p>
            <p className="text-xs text-[#9CA3AF] mt-0.5">Admin</p>
          </div>
          <UserCog className="w-4 h-4 text-[#9CA3AF] opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
      </div>
    </aside>
  );
}
